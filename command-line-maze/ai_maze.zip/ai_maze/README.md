# Navigating AI in Academic Life
**By Zohra Hussaini**

## Instructions
Use the command line to navigate this maze.

Helpful commands:
- `cd` to move between directories
- `ls` and `ls -la` to list files (including hidden ones)
- `cat` to read clues

Start in the `entrance` directory and follow the clues to reach the solution.


